"""Strategist Agent — clusters competitor messaging with TF-IDF embeddings,
ranks angles by ad longevity (longevity = proven performance proxy),
and identifies messaging gaps the user hasn't tried."""
from collections import defaultdict
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
from config import N_CLUSTERS, LONGEVITY_SUCCESS_DAYS
from utils.logger import get_logger

log = get_logger("strategist")

# Angles the user's own brand currently uses (their creative inventory)
USER_CURRENT_ANGLES = {"discount", "quality"}

def run(ads: list, insights: dict) -> dict:
    if not ads:
        return {"winning_angles": [], "gaps": [], "clusters": {}}

    # 1. Cluster ad texts into messaging groups (TF-IDF + KMeans)
    texts = [a["headline"] + " " + a["body"] for a in ads]
    n_clusters = min(N_CLUSTERS, len(texts))
    vec = TfidfVectorizer(stop_words="english")
    X = vec.fit_transform(texts)
    labels = KMeans(n_clusters=n_clusters, random_state=42, n_init=10).fit_predict(X)

    # 2. Rank angles by average longevity of ads using them
    angle_days = defaultdict(list)
    for ad in ads:
        angle = insights.get(ad["ad_id"], {}).get("angle", "general")
        angle_days[angle].append(ad["days_running"])
    ranked = sorted(
        ((angle, sum(d) / len(d), len(d)) for angle, d in angle_days.items()),
        key=lambda t: t[1], reverse=True,
    )
    winning = [
        {"angle": a, "avg_days_running": round(avg, 1), "n_ads": n}
        for a, avg, n in ranked if avg >= LONGEVITY_SUCCESS_DAYS
    ]

    # 3. Gaps = winning angles the user's brand hasn't tried
    gaps = [w for w in winning if w["angle"] not in USER_CURRENT_ANGLES]

    # 4. Cluster summary (for the dashboard)
    clusters = defaultdict(list)
    for ad, lbl in zip(ads, labels):
        clusters[int(lbl)].append(ad["headline"])

    brief = {"winning_angles": winning, "gaps": gaps, "clusters": dict(clusters)}
    log.info("Strategist: %d winning angles, %d gaps found", len(winning), len(gaps))
    return brief
    