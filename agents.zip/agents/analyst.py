"""Analyst Agent — extracts structured intelligence (angle, hook, offer, CTA)
from each competitor ad using the Groq LLM API (Llama 3.3)."""
import json, re
from groq import Groq
from config import GROQ_API_KEY
from utils.prompts import ANALYST_PROMPT
from utils.logger import get_logger

log = get_logger("analyst")
MODEL = "llama-3.3-70b-versatile"

def _get_client():
    if not GROQ_API_KEY:
        raise RuntimeError(
            "GROQ_API_KEY missing. Add it to your .env file. "
            "Get a free key at https://console.groq.com"
        )
    return Groq(api_key=GROQ_API_KEY)

def _analyze_one(client, ad: dict) -> dict:
    prompt = ANALYST_PROMPT.format(
        headline=ad["headline"], body=ad["body"], format=ad["format"]
    )
    resp = client.chat.completions.create(
        model=MODEL,
        messages=[{"role": "user", "content": prompt}],
        temperature=0.2,
        response_format={"type": "json_object"},
    )
    result = json.loads(resp.choices[0].message.content)
    # Guarantee all expected keys exist even if the LLM omits one
    for key in ("angle", "hook", "offer", "cta"):
        result.setdefault(key, "unknown")
    return result

def run(ads: list) -> dict:
    client = _get_client()
    insights = {}
    for ad in ads:
        try:
            insights[ad["ad_id"]] = _analyze_one(client, ad)
        except Exception as e:
            log.warning("Analyst failed on %s: %s", ad["ad_id"], e)
            insights[ad["ad_id"]] = {
                "angle": "unknown", "hook": ad["headline"],
                "offer": "unknown", "cta": "unknown",
            }
    log.info("Analyst: %d ads analyzed via Groq/%s", len(insights), MODEL)
    return insights