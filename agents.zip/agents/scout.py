"""Scout Agent — collects competitor ads from the official Meta Ad Library API.
Endpoint: https://graph.facebook.com/v19.0/ads_archive"""
from datetime import date
import requests
from config import META_ACCESS_TOKEN, COMPETITORS
from utils.logger import get_logger

log = get_logger("scout")

API_URL = "https://graph.facebook.com/v19.0/ads_archive"
FIELDS = "id,ad_creative_bodies,ad_creative_link_titles,ad_delivery_start_time,publisher_platforms"

def _fetch_competitor(comp: str) -> list:
    """Fetch ads for one competitor from the Ad Library."""
    resp = requests.get(
        API_URL,
        params={
            "search_terms": comp,
            "ad_type": "ALL",
            "ad_active_status": "ALL",
            "ad_reached_countries": '["IN"]',
            "fields": FIELDS,
            "limit": 25,
            "access_token": META_ACCESS_TOKEN,
        },
        timeout=30,
    )
    resp.raise_for_status()
    ads = []
    for item in resp.json().get("data", []):
        start = item.get("ad_delivery_start_time", date.today().isoformat())[:10]
        days = (date.today() - date.fromisoformat(start)).days
        ads.append({
            "ad_id": item["id"],
            "competitor": comp,
            "headline": (item.get("ad_creative_link_titles") or [""])[0],
            "body": (item.get("ad_creative_bodies") or [""])[0],
            "format": ",".join(item.get("publisher_platforms", [])) or "unknown",
            "start_date": start,
            "days_running": max(days, 0),
        })
    return ads

def run(known_ids: set):
    if not META_ACCESS_TOKEN:
        raise RuntimeError(
            "META_ACCESS_TOKEN missing. Add it to your .env file. "
            "Get one at https://developers.facebook.com (identity verification required)."
        )
    ads = []
    for comp in COMPETITORS:
        try:
            fetched = _fetch_competitor(comp)
            log.info("Scout: %d ads for '%s'", len(fetched), comp)
            ads.extend(fetched)
        except requests.HTTPError as e:
            log.error("Scout failed for '%s': %s", comp, e.response.text[:200])
    new = [a for a in ads if a["ad_id"] not in known_ids]
    log.info("Scout: %d total, %d new", len(ads), len(new))
    return ads, new